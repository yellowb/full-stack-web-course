//overview.js
var common = require('./common');
common.init();
document.write('<h2>this is overview js</h2>');