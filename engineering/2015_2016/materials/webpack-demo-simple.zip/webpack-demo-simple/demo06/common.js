//common.js
module.exports ={
	init : function(){
		document.write('<h1>this is common js</h1>');
	}
};