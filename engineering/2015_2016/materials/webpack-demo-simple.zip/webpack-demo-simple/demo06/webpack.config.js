var webpack = require("webpack");
module.exports = {
  entry: {
  	overview:'./overview',
  	party:'./party'
  },
  output: {
    filename: '[name].bundle.js'
  },
  plugins: [ new webpack.optimize.CommonsChunkPlugin("common.bundle.js") ]
};