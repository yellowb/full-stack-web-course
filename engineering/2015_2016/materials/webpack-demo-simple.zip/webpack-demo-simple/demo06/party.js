//party.js
var common = require('./common');
common.init();
document.write('<h3>this is party js<h3>');