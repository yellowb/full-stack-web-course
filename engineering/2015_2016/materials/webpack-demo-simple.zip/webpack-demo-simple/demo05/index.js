//index.js
var dsh = require("./dashboard.js");
dsh.init();
document.getElementById("overview_btn").onclick = function(){
	require.ensure([],function(){
		require('./overview.js').init();
	});
};

document.getElementById("party_btn").onclick = function(){
	require.ensure([],function(){
		require('./party.js').init();
	});
};


