//overview.js
module.exports ={
	init : function(){
		alert("Overview tab js loaded");
	}
};
	