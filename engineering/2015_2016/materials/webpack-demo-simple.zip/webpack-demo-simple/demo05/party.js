//party.js
module.exports ={
	init : function(){
		alert("party tab js loaded");
	}
}
