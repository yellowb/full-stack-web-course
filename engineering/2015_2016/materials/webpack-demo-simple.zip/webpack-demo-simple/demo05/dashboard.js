//dashboard.js
module.exports = {
	init : function(){
		document.write("<h1>Index page</h1>");
	}
};
