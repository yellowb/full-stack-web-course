//index.js
require('style-loader!css-loader!./index.css');